# AI Ticket Auto-Responder

![Python](https://img.shields.io/badge/Python-3.9+-blue)
![ML](https://img.shields.io/badge/Machine%20Learning-Scikit--learn-orange)
![LLM](https://img.shields.io/badge/LLM-OpenAI-green)
![FastAPI](https://img.shields.io/badge/API-FastAPI-009688)
![Streamlit](https://img.shields.io/badge/UI-Streamlit-FF4B4B)
![License](https://img.shields.io/badge/License-MIT-lightgrey)

An AI-powered system that classifies support tickets and generates automated responses using Python, Machine Learning, and LLM integration.

## Features
- Ticket classification using ML
- Automated response generation using LLM
- FastAPI backend
- Streamlit web interface

## Setup

### Install dependencies
pip install -r requirements.txt

### Train the model
python src/train.py

### Set API key
Create a `.env` file:
OPENAI_API_KEY=your_api_key_here

### Run the API
uvicorn app.api:app --reload

### Run the UI
streamlit run app/ui.py

## Screenshots
Add screenshots in the `screenshots` folder:
- screenshots/ui.png
- screenshots/response.png
