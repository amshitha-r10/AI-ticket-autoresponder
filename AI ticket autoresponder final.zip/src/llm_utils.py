import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def generate_response(ticket_text, category):
    prompt = f"""
You are an IT support agent.
Ticket category: {category}

Ticket:
{ticket_text}

Write a professional support response with a suggested solution.
"""

    response = client.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[
            {"role": "system", "content": "You are a professional IT support agent."},
            {"role": "user", "content": prompt}
        ]
    )
    return response.choices[0].message.content
