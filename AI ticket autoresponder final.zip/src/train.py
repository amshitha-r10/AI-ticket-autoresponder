import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import joblib
import os

os.makedirs("models", exist_ok=True)

data = pd.read_csv("data/sample_emails.csv")
data["text"] = data["subject"] + " " + data["description"]

vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(data["text"])
y = data["category"]

model = LogisticRegression()
model.fit(X, y)

joblib.dump(model, "models/classifier.pkl")
joblib.dump(vectorizer, "models/vectorizer.pkl")

print("Model trained and saved.")
