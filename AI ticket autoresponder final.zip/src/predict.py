import joblib

model = joblib.load("models/classifier.pkl")
vectorizer = joblib.load("models/vectorizer.pkl")

def predict_category(text):
    vec = vectorizer.transform([text])
    return model.predict(vec)[0]
