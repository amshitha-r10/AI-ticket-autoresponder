import streamlit as st
import requests

st.title("AI Ticket Auto-Responder")

ticket = st.text_area("Enter email or ticket text")

if st.button("Generate Response"):
    response = requests.post(
        "http://127.0.0.1:8000/respond",
        params={"description": ticket}
    )
    result = response.json()

    st.subheader("Predicted Category")
    st.write(result["category"])

    st.subheader("Suggested Response")
    st.write(result["response"])
