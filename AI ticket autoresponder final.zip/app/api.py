from fastapi import FastAPI
from src.predict import predict_category
from src.llm_utils import generate_response

app = FastAPI()

@app.get("/")
def home():
    return {"message": "AI Ticket Auto-Responder API"}

@app.post("/respond")
def respond_to_ticket(description: str):
    category = predict_category(description)
    reply = generate_response(description, category)

    return {
        "category": category,
        "response": reply
    }
